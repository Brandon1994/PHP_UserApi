<?php

namespace App\Message;

final class ListUserMessage
{
    public function __construct()
    {
        //poderia criar parametros recebidos via query params para filtro
    }
}